Preprocessed human activity recognition (HAR) data is reused from https://github.com/chameleonTK/continual-learning-for-HAR under the MIT license. The data has been preprocessed but we have defined
a stratified train/test split based on paricipants.

## PAMAP2 Physical Activity Monitoring Data Set
![](fig/PAMAP2_participant_counts.png)
![](fig/PAMAP2_test_set_activity_distribution.png)

## Daily Sports and Activities Data Set (DSADS)
![](fig/DSADS_participant_counts.png)
![](fig/DSADS_test_set_activity_distribution.png)


## References
Continual learning reaserch using the dataset:
```bibtex
@article{DBLP:journals/tiot/YeNSJZ21,
  author       = {Juan Ye and
                  Pakawat Nakwijit and
                  Martin Schiemer and
                  Saurav Jha and
                  Franco Zambonelli},
  title        = {Continual Activity Recognition with Generative Adversarial Networks},
  journal      = {{ACM} Trans. Internet Things},
  volume       = {2},
  number       = {2},
  pages        = {9:1--9:25},
  year         = {2021},
  url          = {https://doi.org/10.1145/3440036},
  doi          = {10.1145/3440036},
  timestamp    = {Thu, 14 Oct 2021 08:54:51 +0200},
  biburl       = {https://dblp.org/rec/journals/tiot/YeNSJZ21.bib},
  bibsource    = {dblp computer science bibliography, https://dblp.org}
}
```
Describes feature extraction and preprocessing for HAR data:
```bibtex
@inproceedings{DBLP:conf/percom/WangCHPY18,
  author       = {Jindong Wang and
                  Yiqiang Chen and
                  Lisha Hu and
                  Xiaohui Peng and
                  Philip S. Yu},
  title        = {Stratified Transfer Learning for Cross-domain Activity Recognition},
  booktitle    = {2018 {IEEE} International Conference on Pervasive Computing and Communications,
                  PerCom 2018, Athens, Greece, March 19-23, 2018},
  pages        = {1--10},
  publisher    = {{IEEE} Computer Society},
  year         = {2018},
  url          = {https://doi.org/10.1109/PERCOM.2018.8444572},
  doi          = {10.1109/PERCOM.2018.8444572},
  timestamp    = {Fri, 24 Mar 2023 00:03:50 +0100},
  biburl       = {https://dblp.org/rec/conf/percom/WangCHPY18.bib},
  bibsource    = {dblp computer science bibliography, https://dblp.org}
}
```

Original PAMAP2 citation:
```bibtex
@article{DBLP:journals/prl/ChavarriagaSCDTMR13,
  author       = {Ricardo Chavarriaga and
                  Hesam Sagha and
                  Alberto Calatroni and
                  Sundara Tejaswi Digumarti and
                  Gerhard Tr{\"{o}}ster and
                  Jos{\'{e}} del R. Mill{\'{a}}n and
                  Daniel Roggen},
  title        = {The Opportunity challenge: {A} benchmark database for on-body sensor-based
                  activity recognition},
  journal      = {Pattern Recognit. Lett.},
  volume       = {34},
  number       = {15},
  pages        = {2033--2042},
  year         = {2013},
  url          = {https://doi.org/10.1016/j.patrec.2012.12.014},
  doi          = {10.1016/j.patrec.2012.12.014},
  timestamp    = {Mon, 15 Jun 2020 16:59:11 +0200},
  biburl       = {https://dblp.org/rec/journals/prl/ChavarriagaSCDTMR13.bib},
  bibsource    = {dblp computer science bibliography, https://dblp.org}
}
```
Original DSADS citation:
```bibtex
@inproceedings{DBLP:conf/iswc/ReissS12,
  author       = {Attila Reiss and
                  Didier Stricker},
  title        = {Introducing a New Benchmarked Dataset for Activity Monitoring},
  booktitle    = {16th International Symposium on Wearable Computers, {ISWC} 2012, Newcastle,
                  United Kingdom, June 18-22, 2012},
  pages        = {108--109},
  publisher    = {{IEEE} Computer Society},
  year         = {2012},
  url          = {https://doi.org/10.1109/ISWC.2012.13},
  doi          = {10.1109/ISWC.2012.13},
  timestamp    = {Thu, 23 Mar 2023 23:58:33 +0100},
  biburl       = {https://dblp.org/rec/conf/iswc/ReissS12.bib},
  bibsource    = {dblp computer science bibliography, https://dblp.org}
}


```